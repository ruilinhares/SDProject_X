package iVotas.ws;


public class webSocketAnotation {

    public webSocketAnotation(){

    }
}
